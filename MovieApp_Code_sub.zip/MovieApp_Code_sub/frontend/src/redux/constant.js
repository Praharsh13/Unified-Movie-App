export const BASE_URL="";
// constants.js
export const USERS_URL = "http://localhost:3002/movieapp/users"; // This should be correct for your proxy setup

export const GENRE_URL="http://localhost:3002/movieapp/genre" ;


export const MOVIE_URL = "http://localhost:3002/movieapp/movies";//This for movies

export const UPLOAD_URL ="http://localhost:3002/movieapp/upload"; //this is for upload

export const WISHLIST_URL="http://localhost:3002/movieapp/wishlist";
